from .base import CACHE, get_project_followers


def process(client, actions):
    """
    Creates batches of 10 actions at a time to complete using the Asana batch API

    An 'action' is an object with the form
    {
        'data': {
            'custom_fields': { 'some_nome': 'some_value' }
        }, # Payload that would normally be sent to the endpoint
        'method': 'PUT', # Method usually used for the endpoint
        'relative_path': '/tasks/123', # The usual endpoint leaving off of the base path of the API.
    }

    A 'batch' response is an object in the form of
    {
    "body": {
        "data": {
        "completed": false,
        "gid": "1967",
        "name": "Hello, world!",
        "notes": "How are you today?"
        }
    },
    "headers": {
        "location": "/tasks/1234"
    },
    "status_code": 200
    }
    """

    batch_size = 10

    responses = []

    for i in range(0, len(actions), batch_size):
        batch = actions[i : i + batch_size]
        responses += client.post("/batch", {"actions": batch})

    for response in responses:
        if response["status_code"] >= 400:
            print("Errors with request:", response["body"]["errors"])

    return responses


def remove_task_followers(client, project_id, task_ids=[]):
    follower_ids = get_project_followers(client, project_id)
    actions = [
        __remove_task_followers_action(task_id, follower_ids)
        for task_id in (task_ids or CACHE.remote_tasks.values())
    ]
    process(client, actions)


def __remove_task_followers_action(task_id, follower_ids):
    return {
        "data": {"followers": follower_ids},
        "method": "POST",
        "relative_path": f"/tasks/{task_id}/removeFollowers",
    }


def set_all_task_dependencies(client, task_ids=[]):
    """
    Look up remote task id and set dependencies
    """
    actions = []
    for task_id in task_ids or CACHE.remote_tasks.values():
        deps = CACHE.get_task_dependencies(task_id)
        if deps:
            dependency_ids = [CACHE.get_task_id(d["section"], d["name"]) for d in deps]
            actions.append(__set_dependencies_action(task_id, dependency_ids))
    process(client, actions)


def __set_dependencies_action(task_id, dependency_ids):
    return {
        "data": {"dependencies": dependency_ids},
        "method": "POST",
        "relative_path": f"/tasks/{task_id}/addDependencies",
    }


def generate_change_syllabus_section_name_actions(old_section_name, new_section_name):
    """
    Change the `section` portion of each task name from the old value to a new section value.
    This is necessary when the section name in CC is changed.
    """
    actions = []

    for task_key in CACHE.get_tasks_for_syllabus_section(old_section_name):
        task_name_sections = task_key.split("/")

        asana_sections, task_name = task_name_sections[0:-1], task_name_sections[-1]
        if len(asana_sections) == 1:
            asana_section = asana_sections[0]
        elif len(asana_sections) == 2:
            if asana_sections[0:2] == ["Record", "Edit"]:
                asana_section = "/".join(asana_sections[0:2])
                task_name = "/".join(asana_sections[2:] + [task_name])
            else:
                asana_section = asana_sections[0]
                task_name = "/".join(asana_sections[1:] + [task_name])
        else:
            # Things got weird, there are definitely slashes in the syllabus item name or secit
            if asana_sections[0:3] == ["Record", "Edit", "Upload"]:
                asana_section = "/".join(asana_sections[0:3])
                task_name = "/".join(asana_sections[3:] + [task_name])
            elif asana_sections[0:2] == ["Record", "Edit"]:
                asana_section = "/".join(asana_sections[0:2])
                task_name = "/".join(asana_sections[2:] + [task_name])
            else:
                asana_section = asana_sections[0]
                task_name = "/".join(asana_sections[1:] + [task_name])

        task_id = CACHE.get_task_id(asana_section, task_name)

        if task_name.endswith(f": {old_section_name}"):
            new_task_name = task_name.replace(
                f": {old_section_name}", f": {new_section_name}"
            )
        else:
            new_task_name = task_name.replace(
                f" ({old_section_name})", f" ({new_section_name})"
            )

        actions.append(__change_syllabus_section_name_action(task_id, new_task_name))

    CACHE.update_task_actions += actions


def __change_syllabus_section_name_action(task_id, task_name):
    return {
        "data": {"name": task_name},
        "method": "PUT",
        "relative_path": f"/tasks/{task_id}",
    }


def process_all_cached_actions(client):
    """
    Processes all of actions stored in the cache to run later in the process as a batch
    """
    actions = CACHE.update_task_actions + CACHE.subtask_actions
    if actions:
        process(client, actions)

    CACHE.update_task_actions = []
    CACHE.subtask_actions = []
