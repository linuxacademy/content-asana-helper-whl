import os
import pathlib
from functools import lru_cache

from gql import gql, Client
from gql.transport.requests import RequestsHTTPTransport

from requests.exceptions import HTTPError


class CourseNotFoundError(Exception):
    pass


class BadAuthTokenError(Exception):
    pass


DEFAULT_API_URL = "https://prod-api.acloud.guru/bff/graphql"


def new_client(url=DEFAULT_API_URL, auth_token=None, schema=None):
    transport = RequestsHTTPTransport(url=url, retries=3, verify=True)

    if auth_token:
        transport.headers = {"Authorization": f"Bearer {auth_token}"}

    if schema:
        return Client(schema=schema, transport=transport)
    else:
        return Client(transport=transport, fetch_schema_from_transport=True)


@lru_cache(maxsize=32)
def _default_client():
    try:
        return new_client(auth_token=os.environ["CC_AUTH_TOKEN"])
    except HTTPError:
        raise BadAuthTokenError(
            "please ensure that your CC_AUTH_TOKEN value hasn't expired."
        )


__GRAPHQL_DIR = pathlib.Path(__file__).parent.absolute().joinpath("graphql")

with open(__GRAPHQL_DIR.joinpath("fetch_syllabus.graphql"), "r") as f:
    fetch_syllabus_query = gql(f.read())


def fetch_syllabus(course_id, client=None):
    if not client:
        client = _default_client()

    try:
        results = client.execute(fetch_syllabus_query, {"courseId": course_id})
        if not results["courseOverview"]:
            raise CourseNotFoundError(f"unable to find course with id: {course_id}")
    except:
        raise CourseNotFoundError(f"unable to find course with id: {course_id}")

    syllabus = results["courseOverview"]
    return syllabus


def format_syllabus(syllabus):
    new_syllabus = {
        "course_name": syllabus["title"],
        "course_id": syllabus["id"],
        "url": f"https://cloudcraft.linuxacademy.com/courses/details/{syllabus['id']}/map",
        "sections": [],
    }

    content_type_mapping = {
        "video": "lesson",
        "quiz": "exam",
        "hands-on-lab": "lab",
    }

    for section in syllabus["sections"]:
        section_dict = {"name": section["title"], "items": []}

        for comp in section["components"]:
            item_name = comp["title"].strip()
            if comp["content"]["type"] in content_type_mapping.keys():
                item = {
                    "type": content_type_mapping[comp["content"]["type"]],
                    "name": item_name,
                    "description": comp["description"],
                }
            else:
                print(
                    f"Unusual content type: {comp['content']['type']} for {item_name}"
                )
                item = {"type": comp["content"]["type"], "name": item_name}

            section_dict["items"].append(item)

        new_syllabus["sections"].append(section_dict)

    return new_syllabus


def fetch_formatted_syllabus(course_id, client=None):
    return format_syllabus(fetch_syllabus(course_id, client))
